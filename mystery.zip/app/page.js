import Home from "./components/home/Home";

export default function HomePage() {
  return (
    <>
      <Home />
    </>
  );
}
