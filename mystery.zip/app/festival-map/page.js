import React from "react";
import FastivalMap from "../components/fastivalMap/FastivalMap";

export default function FastivalMapPage() {
  return (
    <>
      <FastivalMap />
    </>
  );
}
